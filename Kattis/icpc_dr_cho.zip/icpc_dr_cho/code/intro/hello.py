def solution():
  res = input()
  if res.startswith("Simon says"):
    result = res[strlen:]
    print(result)

count = input()
strlen = len("Simon says")
for i in range(int(count)):
  solution()

